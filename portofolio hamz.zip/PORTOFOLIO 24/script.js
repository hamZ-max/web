        // --- 1. Lenis Smooth Scroll Setup (TETAP) ---
        const lenis = new Lenis({
            duration: 1.2,
            easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
            direction: 'vertical',
            gestureDirection: 'vertical',
            smooth: true,
            mouseMultiplier: 1,
            smoothTouch: false,
            touchMultiplier: 2,
        });

        function raf(time) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }
        requestAnimationFrame(raf);

        // --- 2. Custom Cursor (TETAP) ---
        const cursor = document.querySelector('.cursor-ball');
        const hovers = document.querySelectorAll('a, .p-image-wrap, .char-container, .about-image-container, .skill-tag');

        window.addEventListener('mousemove', (e) => {
            cursor.style.left = e.clientX + 'px';
            cursor.style.top = e.clientY + 'px';
        });

        hovers.forEach(el => {
            el.addEventListener('mouseenter', () => cursor.classList.add('hovered'));
            el.addEventListener('mouseleave', () => cursor.classList.remove('hovered'));
        });

        // --- 3. Three.js: Floating Chrome Objects (TETAP) ---
        const scene = new THREE.Scene();
        scene.fog = new THREE.FogExp2(0x080808, 0.03);

        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(window.devicePixelRatio);
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.outputEncoding = THREE.sRGBEncoding;
        document.getElementById('canvas-container').appendChild(renderer.domElement);

        const material = new THREE.MeshPhysicalMaterial({
            color: 0x111111,
            metalness: 1,
            roughness: 0.1,
            clearcoat: 1.0,
            clearcoatRoughness: 0.1,
        });

        const objects = [];
        const geometry = new THREE.TorusKnotGeometry(1, 0.3, 100, 16);

        for(let i=0; i<3; i++) {
            const mesh = new THREE.Mesh(geometry, material);
            mesh.position.set(
                (Math.random() - 0.5) * 10,
                (Math.random() - 0.5) * 10,
                (Math.random() - 0.5) * 5
            );
            mesh.scale.setScalar(Math.random() * 0.5 + 0.5);
            scene.add(mesh);
            objects.push({
                mesh: mesh,
                speedX: (Math.random() - 0.5) * 0.005,
                speedY: (Math.random() - 0.5) * 0.005,
                rotSpeed: (Math.random() - 0.5) * 0.01
            });
        }

        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);

        const light1 = new THREE.PointLight(0xff4d00, 5, 50);
        const light2 = new THREE.PointLight(0x00aaff, 5, 50);
        scene.add(light1);
        scene.add(light2);

        camera.position.z = 5;

        let mouseX = 0;
        let mouseY = 0;
        window.addEventListener('mousemove', (event) => {
            mouseX = (event.clientX / window.innerWidth) * 2 - 1;
            mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
        });

        const clock = new THREE.Clock();

        function animate() {
            const time = clock.getElapsedTime();

            light1.position.x = Math.sin(time * 0.7) * 5;
            light1.position.y = Math.cos(time * 0.5) * 5;
            light1.position.z = Math.sin(time * 0.3) * 5;

            light2.position.x = Math.cos(time * 0.3) * 5;
            light2.position.y = Math.sin(time * 0.5) * 5;
            light2.position.z = Math.cos(time * 0.7) * 5;

            objects.forEach(obj => {
                obj.mesh.rotation.x += obj.rotSpeed;
                obj.mesh.rotation.y += obj.rotSpeed;
                obj.mesh.position.y += Math.sin(time + obj.mesh.position.x) * 0.002;
                obj.mesh.rotation.x += mouseY * 0.01;
                obj.mesh.rotation.y += mouseX * 0.01;
            });

            renderer.render(scene, camera);
            requestAnimationFrame(animate);
        }
        animate();

        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        // --- 4. GSAP Animations (MODIFIED: NO DISAPPEARING) ---
        gsap.registerPlugin(ScrollTrigger);

        // Hanya animasi background text yang bergerak ke atas sedikit,
        // TAPI opacity dihapus agar tidak menghilang
        gsap.to('#bg-text', {
            scrollTrigger: {
                trigger: '.hero',
                start: "top top",
                end: "bottom top",
                scrub: 1
            },
            y: 200,
            // opacity: 0  <-- DIHAPUS AGAR TIDAK MENGHILANG
        });

        // Project Image Parallax (Hanya bergerak dalam frame, tidak menghilang)
        document.querySelectorAll('.p-image-wrap').forEach(wrap => {
            let img = wrap.querySelector('img');
            gsap.to(img, {
                scrollTrigger: {
                    trigger: wrap,
                    start: "top bottom",
                    end: "bottom top",
                    scrub: 1
                },
                y: -50,
                ease: "none"
            });
        });

        // About Images Parallax (Hanya bergerak sedikit)
        // Dihapus bagian 'from opacity 0'
        document.querySelectorAll('.about-image-container').forEach((container, index) => {
            // Kita gunakan .to untuk parallax effect saja saat scroll
            gsap.to(container, {
                scrollTrigger: {
                    trigger: '.about-visual',
                    start: "top bottom",
                    end: "bottom top",
                    scrub: 1
                },
                y: index === 0 ? -30 : 30, // Gerakan halus ke atas/bawah
                ease: "none"
            });
        });

       // salju
const snowCount = 80;

for (let i = 0; i < snowCount; i++) {

  let snow = document.createElement("div");
  snow.className = "snow";

  // posisi random
  snow.style.left = Math.random() * window.innerWidth + "px";

  // ukuran random
  let size = Math.random() * 15 + 5;
  snow.style.fontSize = size + "px";

  // speed beda-beda
  snow.style.animationDuration = (Math.random() * 5 + 3) + "s";

  // transparansi beda
  snow.style.opacity = Math.random();

  snow.innerHTML = "❄";

  document.body.appendChild(snow);
}

// 1. LOADER
        window.addEventListener('load', () => {
            const loader = document.querySelector('.loader');
            setTimeout(() => {
                loader.classList.add('hidden');
            }, 1000);
        });
